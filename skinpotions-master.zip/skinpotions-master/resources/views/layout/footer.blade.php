<!-- Footer -->
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h4 style="color:#ff6699;"><strong>Skin Potions</strong>
                    </h4>
                    <p style="color:#ff6699;">SM Bacoor (UGF fronting Chowking)
                        <br>SM North (2F Main Mall fronting Max's)
                        <br>SM Megamall (LGF Mega A fronting Motoworld)</p>
                    <ul class="list-unstyled">
                        <li><i class="fa fa-phone fa-fw"></i> (123) 456-7890</li>
                        <li><i class="fa fa-envelope-o fa-fw"></i> <a style="color:#ff6699;" href="mailto:name@example.com">email@skinpotionsph.com</a>
                        </li>
                    </ul>
                    <br>
                    <ul class="list-inline">
                        <li>
                            <a href="#"><i class="fa fa-facebook fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble fa-fw fa-3x"></i></a>
                        </li>
                    </ul>
                    <hr class="small">
                    <p class="text-muted">Copyright &copy; www.skinpotionsph.com</p>
                </div>
            </div>
        </div>
    </footer>